<?php
$host = "localhost";  // Nama host database
$user = "root";       // Nama pengguna database
$password = "";       // Kata sandi pengguna database
$database = "proposalican"; // Nama database

// Membuat koneksi
$conn = new mysqli($host, $user, $password, $database);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
