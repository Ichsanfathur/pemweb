<?php
include 'koneksi.php'; // Menghubungkan ke database

// Query untuk mengambil data dari tabel 'education'
$query = "SELECT title, institution, start_year, end_year, description FROM education";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>

<head>
  <!-- Basic Meta Tags -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <title>Finexo - About Us</title>

  <!-- Fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
  
  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet" />
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
    .education_section {
      padding: 60px 0;
      background-color: #f9f9f9;
    }
    .education_section h2 {
      color: #333;
      font-weight: bold;
      text-align: center;
      margin-bottom: 40px;
    }
    .education_item {
      margin-bottom: 30px;
      padding: 20px;
      border-radius: 10px;
      background-color: #ffffff;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }
    .education_item h4 {
      color: #007bff;
      font-weight: 700;
    }
    .education_item p {
      margin: 5px 0;
      color: #666;
    }
  </style>
</head>

<body class="sub_page">

  <div class="hero_area">
    <div class="hero_bg_box">
      <div class="bg_img_box">
        <img src="images/hero-bg.png" alt="hero background">
      </div>
    </div>

    <!-- Header Section -->
    <?php include 'header.php'; ?>
    <!-- End Header Section -->
  </div>

  <section class="education_section">
    <div class="container">
        <h2>My Education</h2>
        <div class="row">
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <div class="col-md-6">
                    <div class="education_item">
                        <h4><?php echo $row['title']; ?></h4>
                        <p><strong><?php echo $row['institution']; ?></strong></p>
                        <p><i class="fas fa-calendar-alt"></i> <?php echo $row['start_year']; ?> - <?php echo $row['end_year']; ?></p>
                        <p><?php echo $row['description']; ?></p>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</section>

<?php
// Menutup koneksi database
mysqli_close($conn);
?>
  <!-- End Education Section -->

  <!-- Footer Section -->
  <?php include 'footer.php'; ?>
  <!-- End Footer Section -->

  <!-- jQuery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="js/bootstrap.js"></script>
  <!-- Custom JS -->
  <script src="js/custom.js"></script>

</body>

</html>