<header class="header_section">
  <div class="container-fluid">
    <nav class="navbar navbar-expand-lg custom_nav-container ">
      <a class="navbar-brand" href="index.php">
        <span>Portofolio</span>
      </a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class=""> </span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <?php
          // Mendapatkan nama file saat ini
          $current_page = basename($_SERVER['PHP_SELF']);

          // Array dengan nama file dan label navigasi
          $nav_items = [
            'index.php' => 'Home',
            'about.php' => 'About',
            'certificate.php' => 'Certificate',
            'contact.php' => 'Contact',
            'education.php' => 'Education'
          ];

          // Loop untuk menampilkan item navigasi
          foreach ($nav_items as $file => $label) {
            // Tambahkan kelas 'active' jika halaman saat ini cocok dengan item navigasi
            $active_class = ($current_page === $file) ? 'active' : '';
            echo "<li class='nav-item $active_class'>
                    <a class='nav-link' href='$file'>$label</a>
                  </li>";
          }
          ?>
        </ul>
      </div>
    </nav>
  </div>
</header>
