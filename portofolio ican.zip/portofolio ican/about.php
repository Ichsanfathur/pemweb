<!DOCTYPE html>
<html>

<head>
  <!-- Basic Meta Tags -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <title>Finexo - About Me</title>

  <!-- Fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
  
  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet" />
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body class="sub_page">

  <div class="hero_area">
    <div class="hero_bg_box">
      <div class="bg_img_box">
        <img src="images/hero-bg.png" alt="hero background">
      </div>
    </div>

    <!-- Header Section -->
    <?php include 'header.php'; ?>
    <!-- End Header Section -->
  </div>

  <!-- About Section -->
  <section class="about_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>About <span>Us</span></h2>
        
        <?php
        // Aktifkan pelaporan error
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        // Informasi koneksi database
        $host = "localhost";  
        $user = "root";       
        $password = "";       
        $database = "proposalican"; 

        // Coba untuk membuat koneksi
        $conn = new mysqli($host, $user, $password, $database);

        // Cek apakah koneksi berhasil
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query untuk mengambil data dari tabel 'about'
        $sql = "SELECT title, description FROM about";
        $result = $conn->query($sql);

        // Mengecek apakah ada data yang didapat dari query
        if ($result && $result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
            echo "<div class='about-content'>";
            echo "<h3>" . htmlspecialchars($row["title"]) . "</h3>";
            echo "<p>" . htmlspecialchars($row["description"]) . "</p>";
            echo "</div>";
          }
        } else {
          echo "<p>No data found</p>";
        }

        // Menutup koneksi
        $conn->close();
        ?>
        
      </div>
    </div>
  </section>
  <!-- End About Section -->

  <!-- Footer Section -->
  <?php include 'footer.php'; ?>
  <!-- End Footer Section -->

  <!-- jQuery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="js/bootstrap.js"></script>
  <!-- Custom JS -->
  <script src="js/custom.js"></script>

</body>

</html>
