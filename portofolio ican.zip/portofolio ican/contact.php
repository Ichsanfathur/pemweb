<!DOCTYPE html>
<html>

<head>
  <!-- Basic Meta Tags -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <title>Finexo - About Us</title>

  <!-- Fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
  
  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet" />
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body class="sub_page">

  <div class="hero_area">
    <div class="hero_bg_box">
      <div class="bg_img_box">
        <img src="images/hero-bg.png" alt="hero background">
      </div>
    </div>

    <!-- Header Section -->
    <?php include 'header.php'; ?>
    <!-- End Header Section -->
  </div>



  <section class="info_section layout_padding2">
  <div class="container">
    <div class="row">
      <!-- Kontak dan Sosial Media -->
      <div class="col-md-6 col-lg-3 info_col">
        <div class="info_contact">
          <h4>Address</h4>
          <div class="contact_link_box">
            <a href="">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>Medang Lestari</span>
            </a>
            <a href="">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>Call +6288295772711</span>
            </a>
            <a href="">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>Ichsan.war100@gmail.com</span>
            </a>
          </div>
        </div>
        <div class="info_social">
          <a href="">
            <i class="fa fa-facebook" aria-hidden="true"></i>
          </a>
          <a href="">
            <i class="fa fa-twitter" aria-hidden="true"></i>
          </a>
          <a href="">
            <i class="fa fa-linkedin" aria-hidden="true"></i>
          </a>
          <a href="">
            <i class="fa fa-instagram" aria-hidden="true"></i>
          </a>
        </div>
      </div>

      <!-- Informasi Detail -->
      <div class="col-md-6 col-lg-3 info_col">
        <div class="info_detail">
          <h4>Info</h4>
          <p>Untuk Tugas Project UTS Pemograman Web, Enjoy and Welcome My Porto</p>
        </div>
      </div>

      <!-- Maps -->
      <div class="col-md-12 col-lg-6 info_col">
        <h4>Our Location</h4>
        <div class="map_container">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d1983.1192916681972!2d106.72548318063541!3d-6.292312987478005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sid!4v1698314567894!5m2!1sen!2sid"
            width="100%"
            height="300"
            style="border:0;"
            allowfullscreen=""
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade">
          </iframe>
        </div>
      </div>
    </div>
  </div>
</section>


  <!-- jQuery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="js/bootstrap.js"></script>
  <!-- Custom JS -->
  <script src="js/custom.js"></script>

</body>

</html>
